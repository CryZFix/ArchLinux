#!/bin/sh

sensors | grep "temp1:" | tr -d '+' | awk '{print $2}'
